<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
$uid = (int)$_SESSION['user_id'];
$errors = []; $success = '';
try {
    $pdo->query('SELECT id FROM friend_requests LIMIT 1');
} catch (PDOException $e) {
    page_start('Relations étudiantes');
    echo '<section class="content-narrow"><div class="alert error"><strong>La table des amitiés n’est pas encore créée.</strong><p>Dans phpMyAdmin, sélectionne <code>link_unchk</code>, clique sur SQL et exécute le contenu du fichier <code>migrations/upgrade_amitie_v4.sql</code> fourni dans le ZIP.</p></div></section>';
    page_end(); exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = (string)($_POST['action'] ?? '');
    $requestId = filter_var($_POST['request_id'] ?? null, FILTER_VALIDATE_INT);
    $targetId = filter_var($_POST['target_id'] ?? null, FILTER_VALIDATE_INT);
    try {
        if ($action === 'send') {
            if (!$targetId || $targetId === $uid) throw new RuntimeException('Tu ne peux pas t’envoyer une demande à toi-même.');
            $checkUser = $pdo->prepare('SELECT id FROM users WHERE id=?'); $checkUser->execute([$targetId]);
            if (!$checkUser->fetchColumn()) throw new RuntimeException('Cet étudiant n’existe pas.');
            $check = $pdo->prepare('SELECT id,status,sender_id,receiver_id FROM friend_requests WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) LIMIT 1');
            $check->execute([$uid,$targetId,$targetId,$uid]); $existing=$check->fetch();
            if ($existing && $existing['status'] === 'accepted') throw new RuntimeException('Vous êtes déjà amis.');
            if ($existing && (int)$existing['sender_id']===$targetId && $existing['status']==='pending') throw new RuntimeException('Cette personne t’a déjà envoyé une demande. Consulte les demandes reçues.');
            if ($existing && $existing['status']==='pending') throw new RuntimeException('Tu as déjà envoyé une demande à cette personne.');
            if ($existing) {
                $up=$pdo->prepare("UPDATE friend_requests SET sender_id=?, receiver_id=?, status='pending', created_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                $up->execute([$uid,$targetId,$existing['id']]);
            } else {
                $ins=$pdo->prepare("INSERT INTO friend_requests(sender_id,receiver_id,status) VALUES(?,?,'pending')");
                $ins->execute([$uid,$targetId]);
            }
            create_notification($pdo, $targetId, 'friend_request', 'Tu as reçu une nouvelle demande d’amitié.', (int)($existing['id'] ?? $pdo->lastInsertId()));
            $success='Demande d’amitié envoyée.';
        } elseif (in_array($action,['accept','reject'],true)) {
            if (!$requestId) throw new RuntimeException('Demande introuvable.');
            $status = $action === 'accept' ? 'accepted' : 'rejected';
            $up=$pdo->prepare("UPDATE friend_requests SET status=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND receiver_id=? AND status='pending'");
            $up->execute([$status,$requestId,$uid]);
            if (!$up->rowCount()) throw new RuntimeException('Cette demande n’est plus disponible.');
            $success=$action==='accept'?'Demande acceptée. Vous êtes maintenant amis.':'Demande refusée.';
        } elseif ($action === 'cancel') {
            if (!$requestId) throw new RuntimeException('Demande introuvable.');
            $del=$pdo->prepare("DELETE FROM friend_requests WHERE id=? AND sender_id=? AND status='pending'"); $del->execute([$requestId,$uid]);
            if (!$del->rowCount()) throw new RuntimeException('Impossible d’annuler cette demande.');
            $success='Demande annulée.';
        } elseif ($action === 'unfriend') {
            if (!$targetId || $targetId===$uid) throw new RuntimeException('Ami introuvable.');
            $del=$pdo->prepare("DELETE FROM friend_requests WHERE status='accepted' AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?))");
            $del->execute([$uid,$targetId,$targetId,$uid]);
            $success=$del->rowCount()?'Amitié retirée.':'Cette relation n’a pas été trouvée.';
        }
    } catch (RuntimeException $e) { $errors[]=$e->getMessage(); }
      catch (PDOException $e) { error_log($e->getMessage()); $errors[]='Action impossible pour le moment. Réessaie.'; }
}
$incoming=$pdo->prepare("SELECT fr.id,fr.created_at,u.id AS user_id,u.first_name,u.last_name,u.filiere,u.eno,u.avatar_path FROM friend_requests fr JOIN users u ON u.id=fr.sender_id WHERE fr.receiver_id=? AND fr.status='pending' ORDER BY fr.created_at DESC");
$incoming->execute([$uid]); $incoming=$incoming->fetchAll();
$outgoing=$pdo->prepare("SELECT fr.id,fr.created_at,u.id AS user_id,u.first_name,u.last_name,u.filiere,u.avatar_path FROM friend_requests fr JOIN users u ON u.id=fr.receiver_id WHERE fr.sender_id=? AND fr.status='pending' ORDER BY fr.created_at DESC");
$outgoing->execute([$uid]); $outgoing=$outgoing->fetchAll();
$friendsQ=$pdo->prepare("SELECT fr.id,fr.sender_id,fr.receiver_id,fr.created_at,u.id AS user_id,u.first_name,u.last_name,u.filiere,u.eno,u.avatar_path FROM friend_requests fr JOIN users u ON u.id=CASE WHEN fr.sender_id=? THEN fr.receiver_id ELSE fr.sender_id END WHERE (fr.sender_id=? OR fr.receiver_id=?) AND fr.status='accepted' ORDER BY u.last_name,u.first_name");
$friendsQ->execute([$uid,$uid,$uid]); $friends=$friendsQ->fetchAll();
page_start('Mes relations'); ?>
<section class="directory-head"><div class="eyebrow"><span class="dot"></span> Réseau étudiant</div><h1 class="page-title">Tes relations, au même endroit.</h1><p class="muted">Gère les demandes reçues, retrouve les demandes envoyées et consulte tes amis.</p></section>
<?php if($errors):?><div class="alert error"><ul><?php foreach($errors as $er):?><li><?=e($er)?></li><?php endforeach;?></ul></div><?php endif;?>
<?php if($success):?><div class="alert success"><?=e($success)?></div><?php endif;?>
<div class="section-head"><div><h2>Demandes reçues</h2><p><?=count($incoming)?> en attente</p></div></div>
<?php if($incoming):?><section class="student-grid"><?php foreach($incoming as $person):?><article class="student-card"><div class="student-top"><?php if($person['avatar_path']):?><img class="student-avatar" src="<?=e($person['avatar_path'])?>" alt=""><?php else:?><div class="student-avatar avatar-fallback"><?=e(mb_strtoupper(mb_substr($person['first_name'],0,1).mb_substr($person['last_name'],0,1)))?></div><?php endif;?><div><h3><?=e($person['first_name'].' '.$person['last_name'])?></h3><p><?=e($person['filiere'])?></p></div></div><div class="friend-actions"><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="accept"><input type="hidden" name="request_id" value="<?=(int)$person['id']?>"><button class="button primary" type="submit">Accepter</button></form><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="reject"><input type="hidden" name="request_id" value="<?=(int)$person['id']?>"><button class="button secondary" type="submit">Refuser</button></form></div></article><?php endforeach;?></section><?php else:?><div class="empty-state"><h3>Aucune demande reçue</h3><p>Quand un étudiant t’enverra une demande, elle apparaîtra ici.</p><a class="button secondary" href="directory.php">Découvrir les étudiants</a></div><?php endif;?>
<div class="section-head"><div><h2>Demandes envoyées</h2><p><?=count($outgoing)?> en attente</p></div></div>
<?php if($outgoing):?><section class="student-grid"><?php foreach($outgoing as $person):?><article class="student-card"><div class="student-top"><?php if($person['avatar_path']):?><img class="student-avatar" src="<?=e($person['avatar_path'])?>" alt=""><?php else:?><div class="student-avatar avatar-fallback"><?=e(mb_strtoupper(mb_substr($person['first_name'],0,1).mb_substr($person['last_name'],0,1)))?></div><?php endif;?><div><h3><?=e($person['first_name'].' '.$person['last_name'])?></h3><p><?=e($person['filiere'])?></p></div></div><div class="friend-actions"><span class="status-pill pending-pill">En attente</span><form method="post"><?=csrf_field()?><input type="hidden" name="action" value="cancel"><input type="hidden" name="request_id" value="<?=(int)$person['id']?>"><button class="button secondary" type="submit">Annuler la demande</button></form></div></article><?php endforeach;?></section><?php else:?><div class="empty-state compact-empty"><p>Aucune demande envoyée en attente.</p></div><?php endif;?>
<div class="section-head"><div><h2>Mes amis</h2><p><?=count($friends)?> étudiant(s)</p></div></div>
<?php if($friends):?><section class="student-grid"><?php foreach($friends as $person):?><article class="student-card"><div class="student-top"><?php if($person['avatar_path']):?><img class="student-avatar" src="<?=e($person['avatar_path'])?>" alt=""><?php else:?><div class="student-avatar avatar-fallback"><?=e(mb_strtoupper(mb_substr($person['first_name'],0,1).mb_substr($person['last_name'],0,1)))?></div><?php endif;?><div><h3><?=e($person['first_name'].' '.$person['last_name'])?></h3><p><?=e($person['filiere'])?></p></div></div><div class="friend-actions"><span class="status-pill">Amis</span><form method="post" data-confirm="Cette personne sera retirée de ta liste d’amis. Tu pourras lui envoyer une nouvelle demande plus tard." data-confirm-title="Retirer cet ami ?" data-confirm-button="Oui, retirer"><?=csrf_field()?><input type="hidden" name="action" value="unfriend"><input type="hidden" name="target_id" value="<?=(int)$person['user_id']?>"><button class="button secondary" type="submit">Retirer</button></form></div></article><?php endforeach;?></section><?php else:?><div class="empty-state"><h3>Ton réseau commence ici</h3><p>Ajoute des étudiants pour développer ton réseau universitaire.</p><a class="button primary" href="directory.php">Trouver des étudiants</a></div><?php endif;?>
<?php page_end(); ?>
