<?php
declare(strict_types=1);

$host = 'localhost';
$dbname = 'link_unchk';
$username = 'root';
$password = ''; // Mot de passe MySQL local, si tu en as défini un.

try {
    $pdo = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit('Connexion à la base de données impossible. Vérifie config/database.php.');
}
