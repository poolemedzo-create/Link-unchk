<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (!empty($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}
page_start('Accueil');
?>
<section class="hero">
  <div class="eyebrow"><span class="dot"></span> Le réseau étudiant de l’UNCHK</div>
  <h1>Les bonnes connexions<br><span>font avancer les idées.</span></h1>
  <p class="lead">Rencontre des étudiants, partage tes projets, trouve des coéquipiers et reste au courant de la vie universitaire.</p>
  <div class="actions">
    <a class="button primary" href="register.php">Rejoindre Link UNCHK <span>→</span></a>
    <a class="button secondary" href="login.php">J’ai déjà un compte</a>
  </div>
  <div class="hero-note"><span class="avatar-stack"><i>M</i><i>A</i><i>+</i></span> Études · Projets · Communauté</div>
</section>
<section class="feature-grid">
  <article class="feature"><div class="feature-icon">↗</div><h3>Développe ton réseau</h3><p>Découvre des étudiants selon leur filière, leur ENO et leurs compétences.</p></article>
  <article class="feature"><div class="feature-icon">⌘</div><h3>Fais avancer tes projets</h3><p>Présente tes réalisations et trouve des personnes motivées pour collaborer.</p></article>
  <article class="feature"><div class="feature-icon">◷</div><h3>Reste informé</h3><p>Retrouve les actualités, événements et activités de la communauté.</p></article>
</section>
<?php page_end(); ?>
