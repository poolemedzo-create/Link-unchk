-- Link UNCHK v7 : notifications, groupes, événements et modération.
-- Migration additive : aucune table existante ni aucun enregistrement n'est supprimé.
CREATE TABLE IF NOT EXISTS notifications (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 type VARCHAR(60) NOT NULL,
 message VARCHAR(500) NOT NULL,
 related_id BIGINT UNSIGNED NULL,
 is_read TINYINT(1) NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_notifications_user (user_id,is_read,created_at),
 CONSTRAINT fk_v7_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS student_groups (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(150) NOT NULL, description TEXT NULL, avatar_path VARCHAR(255) NULL,
 created_by BIGINT UNSIGNED NOT NULL,
 group_type ENUM('discussion','project') NOT NULL DEFAULT 'discussion',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_v7_groups_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS group_members (
 group_id BIGINT UNSIGNED NOT NULL, user_id BIGINT UNSIGNED NOT NULL,
 member_role ENUM('member','moderator','owner') NOT NULL DEFAULT 'member',
 joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(group_id,user_id),
 CONSTRAINT fk_v7_gm_group FOREIGN KEY (group_id) REFERENCES student_groups(id) ON DELETE CASCADE,
 CONSTRAINT fk_v7_gm_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS group_posts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, group_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL, content TEXT NOT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_group_posts (group_id,created_at),
 CONSTRAINT fk_v7_gp_group FOREIGN KEY (group_id) REFERENCES student_groups(id) ON DELETE CASCADE,
 CONSTRAINT fk_v7_gp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS events (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(200) NOT NULL, description TEXT NOT NULL,
 location VARCHAR(255) NULL, event_date DATETIME NOT NULL, end_date DATETIME NULL,
 image_path VARCHAR(255) NULL, organizer_user_id BIGINT UNSIGNED NULL, organizer_club_id BIGINT UNSIGNED NULL,
 status ENUM('pending','published','rejected','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_v7_events_date_status(event_date,status),
 CONSTRAINT fk_v7_events_user FOREIGN KEY (organizer_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS event_bookmarks (
 event_id BIGINT UNSIGNED NOT NULL,user_id BIGINT UNSIGNED NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(event_id,user_id),
 CONSTRAINT fk_v7_eb_event FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
 CONSTRAINT fk_v7_eb_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS admin_users (
 user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_v7_admin_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS content_reports (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, reporter_id BIGINT UNSIGNED NOT NULL,
 post_id BIGINT UNSIGNED NULL, comment_id BIGINT UNSIGNED NULL, reason VARCHAR(500) NOT NULL,
 status ENUM('open','reviewed','dismissed') NOT NULL DEFAULT 'open', created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_reports_status(status,created_at),
 CONSTRAINT fk_v7_reporter FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
 CONSTRAINT fk_v7_report_post FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
 CONSTRAINT fk_v7_report_comment FOREIGN KEY (comment_id) REFERENCES post_comments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
