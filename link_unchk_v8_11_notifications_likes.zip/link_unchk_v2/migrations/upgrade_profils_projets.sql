-- Migration Link UNCHK v2 : profils, compétences et portfolio
-- Sélectionner la base link_unchk dans phpMyAdmin avant d'importer ce fichier.
-- Cette migration n'efface aucune donnée existante.
USE link_unchk;

CREATE TABLE IF NOT EXISTS user_skills (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id BIGINT UNSIGNED NOT NULL,
  skill_name VARCHAR(80) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user_skill (user_id, skill_name),
  INDEX idx_skill_name (skill_name),
  CONSTRAINT fk_user_skills_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
