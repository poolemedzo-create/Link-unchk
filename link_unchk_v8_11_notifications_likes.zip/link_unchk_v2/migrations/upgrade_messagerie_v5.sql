-- Link UNCHK v5 : messagerie privee
-- Dans phpMyAdmin : selectionne link_unchk > SQL, colle ce script puis Execute.
-- Cree une table dediee sans toucher aux tables ni aux messages existants.
CREATE TABLE IF NOT EXISTS private_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sender_id BIGINT UNSIGNED NOT NULL,
  receiver_id BIGINT UNSIGNED NOT NULL,
  body TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  read_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY idx_pm_sender_receiver_id (sender_id, receiver_id, id),
  KEY idx_pm_receiver_unread (receiver_id, read_at, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
