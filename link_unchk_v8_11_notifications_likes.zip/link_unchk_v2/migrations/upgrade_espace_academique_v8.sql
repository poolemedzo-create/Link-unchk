-- Link UNCHK v8 : espace académique (migration additive, sans suppression de données)
CREATE TABLE IF NOT EXISTS academic_resources (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 title VARCHAR(200) NOT NULL,
 description TEXT NULL,
 filiere VARCHAR(150) NOT NULL,
 niveau VARCHAR(80) NOT NULL,
 matiere VARCHAR(150) NOT NULL,
 resource_type ENUM('cours','fiche','exercice','corrige','annale','autre') NOT NULL DEFAULT 'cours',
 original_filename VARCHAR(255) NOT NULL,
 stored_filename VARCHAR(255) NOT NULL,
 mime_type VARCHAR(120) NOT NULL,
 file_size INT UNSIGNED NOT NULL DEFAULT 0,
 status ENUM('pending','published','rejected') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_academic_filter (status,filiere,niveau,matiere,resource_type,created_at),
 INDEX idx_academic_user (user_id,created_at),
 CONSTRAINT fk_academic_resource_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
