-- Link UNCHK v8.3 : confidentialité des comptes. Migration additive et non destructive.
-- À exécuter dans la base link_unchk via phpMyAdmin.
ALTER TABLE users ADD COLUMN is_private TINYINT(1) NOT NULL DEFAULT 0;
