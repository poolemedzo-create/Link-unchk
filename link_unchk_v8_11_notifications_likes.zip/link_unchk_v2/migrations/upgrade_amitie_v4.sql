-- Link UNCHK v4 : demandes d'amitie
-- Dans phpMyAdmin : selectionne link_unchk > SQL, colle ce script puis Execute.
-- Cette table est ajoutee sans supprimer ni modifier les comptes existants.
CREATE TABLE IF NOT EXISTS friend_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sender_id BIGINT UNSIGNED NOT NULL,
  receiver_id BIGINT UNSIGNED NOT NULL,
  status ENUM('pending','accepted','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_friend_pair (sender_id, receiver_id),
  KEY idx_friend_receiver_status (receiver_id, status),
  KEY idx_friend_sender_status (sender_id, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
