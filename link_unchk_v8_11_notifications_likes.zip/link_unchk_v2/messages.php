<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
$uid = (int)$_SESSION['user_id'];
$errors = [];
$success = '';
$activeId = filter_var($_GET['with'] ?? $_POST['with'] ?? null, FILTER_VALIDATE_INT);
if (!$activeId || $activeId === $uid) $activeId = 0;

function are_friends(PDO $pdo, int $a, int $b): bool {
    $q = $pdo->prepare("SELECT id FROM friend_requests WHERE status='accepted' AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)) LIMIT 1");
    $q->execute([$a, $b, $b, $a]);
    return (bool)$q->fetchColumn();
}

try {
    $pdo->query('SELECT id FROM private_messages LIMIT 1');
} catch (PDOException $e) {
    page_start('Messagerie privée');
    echo '<section class="content-narrow"><div class="alert error"><strong>La messagerie n’est pas encore activée.</strong><p>Dans phpMyAdmin, sélectionne <code>link_unchk</code>, clique sur <strong>SQL</strong> et exécute le contenu de <code>migrations/upgrade_messagerie_v5.sql</code> fourni dans ce ZIP.</p></div></section>';
    page_end(); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = (string)($_POST['action'] ?? 'send');
    if ($action === 'send') {
        $body = trim((string)($_POST['body'] ?? ''));
        if (!$activeId) $errors[] = 'Choisis un ami pour commencer une conversation.';
        elseif (!are_friends($pdo, $uid, $activeId)) $errors[] = 'Tu peux envoyer des messages privés uniquement à tes amis.';
        elseif ($body === '') $errors[] = 'Écris un message avant de l’envoyer.';
        elseif (mb_strlen($body) > 4000) $errors[] = 'Le message ne peut pas dépasser 4 000 caractères.';
        if (!$errors) {
            $ins = $pdo->prepare('INSERT INTO private_messages (sender_id, receiver_id, body) VALUES (?, ?, ?)');
            $ins->execute([$uid, $activeId, $body]);
            header('Location: messages.php?with=' . $activeId . '#latest'); exit;
        }
    }
}

// Liste des amis autorisés à discuter.
$friendQ = $pdo->prepare("SELECT u.id, u.first_name, u.last_name, u.filiere, u.avatar_path FROM friend_requests fr JOIN users u ON u.id=CASE WHEN fr.sender_id=? THEN fr.receiver_id ELSE fr.sender_id END WHERE (fr.sender_id=? OR fr.receiver_id=?) AND fr.status='accepted' ORDER BY u.last_name, u.first_name");
$friendQ->execute([$uid, $uid, $uid]);
$friends = $friendQ->fetchAll();
$friendIds = array_map(static fn($f) => (int)$f['id'], $friends);
if ($activeId && !in_array($activeId, $friendIds, true)) {
    $errors[] = 'Cette conversation est inaccessible : vous devez être amis pour échanger des messages.';
    $activeId = 0;
}

// Marquer comme lus uniquement les messages reçus par l’utilisateur connecté.
if ($activeId) {
    $read = $pdo->prepare('UPDATE private_messages SET read_at=CURRENT_TIMESTAMP WHERE sender_id=? AND receiver_id=? AND read_at IS NULL');
    $read->execute([$activeId, $uid]);
}

// Préparer une dernière activité et un compteur de non-lus par ami.
foreach ($friends as &$friend) {
    $last = $pdo->prepare('SELECT body, sender_id, created_at FROM private_messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY id DESC LIMIT 1');
    $last->execute([$uid, $friend['id'], $friend['id'], $uid]);
    $friend['last_message'] = $last->fetch() ?: null;
    $unread = $pdo->prepare('SELECT COUNT(*) FROM private_messages WHERE sender_id=? AND receiver_id=? AND read_at IS NULL');
    $unread->execute([$friend['id'], $uid]);
    $friend['unread'] = (int)$unread->fetchColumn();
}
unset($friend);
usort($friends, static function($a, $b) {
    $ta = $a['last_message']['created_at'] ?? '';
    $tb = $b['last_message']['created_at'] ?? '';
    if ($ta !== $tb) return strcmp($tb, $ta);
    return strcasecmp($a['last_name'] . $a['first_name'], $b['last_name'] . $b['first_name']);
});

$activeFriend = null;
$thread = [];
if ($activeId) {
    foreach ($friends as $friend) if ((int)$friend['id'] === $activeId) { $activeFriend = $friend; break; }
    $q = $pdo->prepare('SELECT id, sender_id, receiver_id, body, created_at FROM private_messages WHERE (sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?) ORDER BY id ASC LIMIT 500');
    $q->execute([$uid, $activeId, $activeId, $uid]);
    $thread = $q->fetchAll();
}

page_start('Messagerie privée');
?>
<section class="directory-head">
  <div class="eyebrow"><span class="dot"></span> Espace privé</div>
  <h1 class="page-title">La conversation continue ici.</h1>
  <p class="muted">Échange des messages avec tes amis de la communauté UNCHK. Seuls les deux participants peuvent consulter une conversation.</p>
</section>
<?php if ($errors): ?><div class="alert error"><ul><?php foreach ($errors as $er): ?><li><?=e($er)?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if ($success): ?><div class="alert success"><?=e($success)?></div><?php endif; ?>
<?php if (!$friends): ?>
  <section class="empty-state"><div class="empty-icon">✉</div><h3>Ta messagerie est prête à démarrer</h3><p>Tu dois d’abord avoir au moins un ami pour envoyer un message privé.</p><a class="button primary" href="directory.php">Trouver des étudiants</a><a class="button secondary" href="friends.php">Voir mes demandes</a></section>
<?php else: ?>
<div class="messenger-layout">
  <aside class="conversation-sidebar">
    <div class="conversation-sidebar-head"><div><h2>Conversations</h2><p><?=count($friends)?> ami(s)</p></div><span class="conversation-count"><?=array_sum(array_column($friends, 'unread'))?></span></div>
    <div class="conversation-list">
    <?php foreach ($friends as $friend): $fid=(int)$friend['id']; $isActive=$fid===$activeId; $initials=mb_strtoupper(mb_substr($friend['first_name'],0,1).mb_substr($friend['last_name'],0,1)); ?>
      <a class="conversation-person <?=$isActive?'active':''?>" href="messages.php?with=<?=$fid?>">
        <?php if (!empty($friend['avatar_path'])): ?><img class="conversation-avatar" src="<?=e($friend['avatar_path'])?>" alt=""><?php else: ?><span class="conversation-avatar avatar-fallback"><?=e($initials)?></span><?php endif; ?>
        <span class="conversation-person-copy"><strong><?=e($friend['first_name'].' '.$friend['last_name'])?></strong><small><?=e($friend['last_message'] ? mb_strimwidth(((int)$friend['last_message']['sender_id']===$uid?'Moi : ':'').$friend['last_message']['body'],0,48,'…') : ($friend['filiere'] ?: 'Aucun message pour le moment'))?></small></span>
        <?php if ($friend['unread']): ?><span class="unread-badge"><?=$friend['unread']?></span><?php endif; ?>
      </a>
    <?php endforeach; ?>
    </div>
  </aside>
  <section class="chat-panel">
  <?php if (!$activeFriend): ?>
    <div class="chat-placeholder"><div class="chat-placeholder-icon">✦</div><h2>Choisis une conversation</h2><p>Sélectionne un ami à gauche ou démarre une nouvelle conversation depuis cette liste.</p></div>
  <?php else: ?>
    <header class="chat-header">
      <a class="chat-profile-identity" href="student.php?id=<?=$activeId?>" title="Voir le profil et les projets de <?=e($activeFriend['first_name'].' '.$activeFriend['last_name'])?>">
      <?php if (!empty($activeFriend['avatar_path'])): ?><img class="conversation-avatar" src="<?=e($activeFriend['avatar_path'])?>" alt="Photo de profil"><?php else: ?><span class="conversation-avatar avatar-fallback"><?=e(mb_strtoupper(mb_substr($activeFriend['first_name'],0,1).mb_substr($activeFriend['last_name'],0,1)))?></span><?php endif; ?>
      <span><h2><?=e($activeFriend['first_name'].' '.$activeFriend['last_name'])?></h2><p><?=e($activeFriend['filiere'] ?: 'Étudiant UNCHK')?> · Voir le profil</p></span></a>
      <a class="button secondary chat-profile-link" href="student.php?id=<?=$activeId?>">Profil</a>
    </header>
    <div class="chat-messages" id="chatMessages">
      <?php if (!$thread): ?><div class="chat-first-message"><span>👋</span><strong>Dis bonjour !</strong><p>Cette conversation est privée entre vous deux.</p></div><?php endif; ?>
      <?php foreach ($thread as $message): $mine=(int)$message['sender_id']===$uid; ?>
        <div class="message-row <?=$mine?'mine':'theirs'?>"><div class="message-bubble"><?=nl2br(e($message['body']))?><time><?=e(date('d/m/Y · H:i', strtotime($message['created_at'])))?></time></div></div>
      <?php endforeach; ?><div id="latest"></div>
    </div>
    <form class="chat-compose" method="post" action="messages.php?with=<?=$activeId?>#latest">
      <?=csrf_field()?> <input type="hidden" name="action" value="send"><input type="hidden" name="with" value="<?=$activeId?>">
      <label class="sr-only" for="messageBody">Ton message</label><textarea id="messageBody" name="body" rows="2" maxlength="4000" required placeholder="Écris ton message…"></textarea>
      <button class="button primary send-message-button" type="submit"><span>Envoyer</span><span aria-hidden="true">➤</span></button>
      <p class="compose-note">Entrée pour écrire dans la zone, puis clique sur Envoyer · 4 000 caractères maximum.</p>
    </form>
    <script>const chat=document.getElementById('chatMessages');if(chat)chat.scrollTop=chat.scrollHeight;</script>
  <?php endif; ?>
  </section>
</div>
<?php endif; ?>
<?php page_end(); ?>
