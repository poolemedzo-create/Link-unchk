<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
$uid = (int)$_SESSION['user_id'];
$errors = [];
$success = '';
$uploadDir = __DIR__ . '/assets/uploads/posts';
$uploadUrl = 'assets/uploads/posts';

// Detecter clairement une installation dont les tables ne sont pas encore actives.
try {
    $pdo->query('SELECT id FROM posts LIMIT 1');
    $pdo->query('SELECT post_id FROM post_likes LIMIT 1');
    $pdo->query('SELECT id FROM post_comments LIMIT 1');
} catch (PDOException $e) {
    page_start('Fil d’actualité');
    echo '<section class="content-narrow"><div class="alert error"><strong>Le fil d’actualité n’est pas encore activé.</strong><p>Dans phpMyAdmin, sélectionne <code>link_unchk</code>, clique sur <strong>SQL</strong> et exécute le fichier <code>migrations/upgrade_fil_actualite_v6.sql</code> fourni dans ce ZIP.</p></div></section>';
    page_end(); exit;
}

function feed_is_friend(PDO $pdo, int $a, int $b): bool {
    $q = $pdo->prepare("SELECT 1 FROM friend_requests WHERE status='accepted' AND ((sender_id=? AND receiver_id=?) OR (sender_id=? AND receiver_id=?)) LIMIT 1");
    $q->execute([$a, $b, $b, $a]);
    return (bool)$q->fetchColumn();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = (string)($_POST['action'] ?? '');
    $postId = filter_var($_POST['post_id'] ?? null, FILTER_VALIDATE_INT);
    try {
        if ($action === 'publish') {
            $content = trim((string)($_POST['content'] ?? ''));
            $visibility = (string)($_POST['visibility'] ?? 'public');
            if (!in_array($visibility, ['public', 'friends'], true)) $visibility = 'public';
            if (mb_strlen($content) > 5000) throw new RuntimeException('La publication est trop longue (maximum 5 000 caractères).');
            $imagePath = null;
            $hasFile = isset($_FILES['post_image']) && (($_FILES['post_image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE);
            if ($content === '' && !$hasFile) throw new RuntimeException('Écris un message ou ajoute une photo avant de publier.');
            if ($hasFile) {
                $file = $_FILES['post_image'];
                if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Le téléversement de la photo a échoué. Réessaie.');
                if (($file['size'] ?? 0) > 5 * 1024 * 1024) throw new RuntimeException('La photo doit faire 5 Mo maximum.');
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($file['tmp_name']);
                $extensions = ['image/jpeg'=>'jpg', 'image/png'=>'png', 'image/webp'=>'webp', 'image/gif'=>'gif'];
                if (!isset($extensions[$mime])) throw new RuntimeException('Format non accepté. Utilise une image JPG, PNG, WEBP ou GIF.');
                if (!is_dir($uploadDir) && !mkdir($uploadDir, 0775, true) && !is_dir($uploadDir)) throw new RuntimeException('Le dossier de photos ne peut pas être créé.');
                $filename = bin2hex(random_bytes(16)) . '.' . $extensions[$mime];
                if (!move_uploaded_file($file['tmp_name'], $uploadDir . '/' . $filename)) throw new RuntimeException('Impossible d’enregistrer la photo. Vérifie les permissions du dossier.');
                $imagePath = $uploadUrl . '/' . $filename;
            }
            try {
                $ins = $pdo->prepare('INSERT INTO posts (user_id, content, image_path, visibility) VALUES (?, ?, ?, ?)');
                $ins->execute([$uid, $content, $imagePath, $visibility]);
            } catch (Throwable $e) {
                if ($imagePath && is_file(__DIR__ . '/' . $imagePath)) @unlink(__DIR__ . '/' . $imagePath);
                throw $e;
            }
            header('Location: feed.php?published=1'); exit;
        } elseif ($action === 'like') {
            if (!$postId) throw new RuntimeException('Publication introuvable.');
            $visible = $pdo->prepare("SELECT p.id FROM posts p WHERE p.id=? AND (p.visibility='public' OR p.user_id=? OR (p.visibility='friends' AND EXISTS (SELECT 1 FROM friend_requests fr WHERE fr.status='accepted' AND ((fr.sender_id=p.user_id AND fr.receiver_id=?) OR (fr.sender_id=? AND fr.receiver_id=p.user_id))))) LIMIT 1");
            $visible->execute([$postId, $uid, $uid, $uid]);
            if (!$visible->fetchColumn()) throw new RuntimeException('Cette publication n’est pas accessible.');
            $check = $pdo->prepare('SELECT 1 FROM post_likes WHERE post_id=? AND user_id=?'); $check->execute([$postId, $uid]);
            if ($check->fetchColumn()) { $del = $pdo->prepare('DELETE FROM post_likes WHERE post_id=? AND user_id=?'); $del->execute([$postId, $uid]); }
            else { $ins = $pdo->prepare('INSERT IGNORE INTO post_likes (post_id,user_id) VALUES (?,?)'); $ins->execute([$postId, $uid]); $ownerQ=$pdo->prepare('SELECT user_id FROM posts WHERE id=?'); $ownerQ->execute([$postId]); $owner=(int)$ownerQ->fetchColumn(); if($owner && $owner!==$uid){create_notification($pdo,$owner,'like','Un étudiant a aimé ta publication.',$postId);} }
            header('Location: feed.php#post-' . $postId); exit;
        } elseif ($action === 'comment') {
            $comment = trim((string)($_POST['comment'] ?? ''));
            if (!$postId) throw new RuntimeException('Publication introuvable.');
            if ($comment === '' || mb_strlen($comment) > 1500) throw new RuntimeException('Le commentaire doit contenir entre 1 et 1 500 caractères.');
            $visible = $pdo->prepare("SELECT p.id FROM posts p WHERE p.id=? AND (p.visibility='public' OR p.user_id=? OR (p.visibility='friends' AND EXISTS (SELECT 1 FROM friend_requests fr WHERE fr.status='accepted' AND ((fr.sender_id=p.user_id AND fr.receiver_id=?) OR (fr.sender_id=? AND fr.receiver_id=p.user_id))))) LIMIT 1");
            $visible->execute([$postId, $uid, $uid, $uid]);
            if (!$visible->fetchColumn()) throw new RuntimeException('Cette publication n’est pas accessible.');
            $ins = $pdo->prepare('INSERT INTO post_comments (post_id,user_id,content) VALUES (?,?,?)'); $ins->execute([$postId, $uid, $comment]); $ownerQ=$pdo->prepare('SELECT user_id FROM posts WHERE id=?'); $ownerQ->execute([$postId]); $owner=(int)$ownerQ->fetchColumn(); if($owner && $owner!==$uid){create_notification($pdo,$owner,'comment','Un étudiant a commenté ta publication.',$postId);}
            header('Location: feed.php#post-' . $postId); exit;
        } elseif ($action === 'report_post') {
            if (!$postId) throw new RuntimeException('Publication introuvable.');
            $reason = trim((string)($_POST['reason'] ?? 'Contenu inapproprié'));
            $check = $pdo->prepare('SELECT id FROM posts WHERE id=?'); $check->execute([$postId]);
            if (!$check->fetchColumn()) throw new RuntimeException('Publication introuvable.');
            $ins = $pdo->prepare('INSERT INTO content_reports(reporter_id,post_id,reason) VALUES(?,?,?)'); $ins->execute([$uid,$postId,mb_substr($reason,0,500)]);
            header('Location: feed.php?reported=1#post-' . $postId); exit;
        } elseif ($action === 'report_comment') {
            $commentId = (int)($_POST['comment_id'] ?? 0); $reason = trim((string)($_POST['reason'] ?? 'Commentaire inapproprié'));
            $check = $pdo->prepare('SELECT id,post_id FROM post_comments WHERE id=?'); $check->execute([$commentId]); $reported=$check->fetch();
            if (!$reported) throw new RuntimeException('Commentaire introuvable.');
            $ins = $pdo->prepare('INSERT INTO content_reports(reporter_id,comment_id,post_id,reason) VALUES(?,?,?,?)'); $ins->execute([$uid,$commentId,(int)$reported['post_id'],mb_substr($reason,0,500)]);
            header('Location: feed.php?reported=1#post-' . (int)$reported['post_id']); exit;
        } elseif ($action === 'delete_comment') {
            $commentId = filter_var($_POST['comment_id'] ?? null, FILTER_VALIDATE_INT);
            if (!$commentId) throw new RuntimeException('Commentaire introuvable.');
            // Un étudiant peut supprimer uniquement son propre commentaire.
            $find = $pdo->prepare('SELECT post_id FROM post_comments WHERE id=? AND user_id=?');
            $find->execute([$commentId, $uid]);
            $commentPostId = $find->fetchColumn();
            if (!$commentPostId) throw new RuntimeException('Tu ne peux supprimer que tes propres commentaires.');
            $del = $pdo->prepare('DELETE FROM post_comments WHERE id=? AND user_id=?');
            $del->execute([$commentId, $uid]);
            header('Location: feed.php?comment_deleted=1#post-' . (int)$commentPostId); exit;
        } elseif ($action === 'delete') {
            if (!$postId) throw new RuntimeException('Publication introuvable.');
            $q = $pdo->prepare('SELECT image_path FROM posts WHERE id=? AND user_id=?'); $q->execute([$postId, $uid]); $own = $q->fetch();
            if (!$own) throw new RuntimeException('Tu ne peux supprimer que tes propres publications.');
            $del = $pdo->prepare('DELETE FROM posts WHERE id=? AND user_id=?'); $del->execute([$postId, $uid]);
            if (!empty($own['image_path']) && str_starts_with($own['image_path'], $uploadUrl . '/') && is_file(__DIR__ . '/' . $own['image_path'])) @unlink(__DIR__ . '/' . $own['image_path']);
            header('Location: feed.php?deleted=1'); exit;
        }
    } catch (RuntimeException $e) { $errors[] = $e->getMessage(); }
      catch (Throwable $e) { error_log('Link UNCHK feed: ' . $e->getMessage()); $errors[] = 'Action impossible pour le moment. Vérifie la configuration puis réessaie.'; }
}
if (isset($_GET['published'])) $success = 'Ta publication a bien été ajoutée au fil d’actualité.';
if (isset($_GET['deleted'])) $success = 'Publication supprimée.';
if (isset($_GET['comment_deleted'])) $success = 'Commentaire supprimé.';
if (isset($_GET['reported'])) $success = 'Merci, ton signalement a été transmis à la modération.';

$sql = "SELECT p.id,p.user_id,p.content,p.image_path,p.visibility,p.created_at,u.first_name,u.last_name,u.avatar_path,u.filiere,
        (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id=p.id) AS like_count,
        (SELECT COUNT(*) FROM post_comments pc WHERE pc.post_id=p.id) AS comment_count,
        EXISTS(SELECT 1 FROM post_likes mine WHERE mine.post_id=p.id AND mine.user_id=?) AS liked_by_me
        FROM posts p JOIN users u ON u.id=p.user_id
        WHERE p.visibility='public' OR p.user_id=? OR (p.visibility='friends' AND EXISTS (
          SELECT 1 FROM friend_requests fr WHERE fr.status='accepted' AND ((fr.sender_id=p.user_id AND fr.receiver_id=?) OR (fr.sender_id=? AND fr.receiver_id=p.user_id))
        )) ORDER BY p.created_at DESC LIMIT 100";
$stmt = $pdo->prepare($sql); $stmt->execute([$uid,$uid,$uid,$uid]); $posts = $stmt->fetchAll();
$commentsByPost = [];
if ($posts) {
    $ids = array_map(static fn($p) => (int)$p['id'], $posts);
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $c = $pdo->prepare("SELECT c.id,c.post_id,c.user_id,c.content,c.created_at,u.first_name,u.last_name,u.avatar_path FROM post_comments c JOIN users u ON u.id=c.user_id WHERE c.post_id IN ($marks) ORDER BY c.created_at ASC");
    $c->execute($ids);
    foreach ($c->fetchAll() as $comment) $commentsByPost[(int)$comment['post_id']][] = $comment;
}
page_start('Fil d’actualité');
?>
<section class="directory-head feed-intro"><div class="eyebrow"><span class="dot"></span> La communauté UNCHK</div><h1 class="page-title">Le fil de la communauté.</h1><p class="muted">Partage tes idées, tes avancées et tes photos avec les autres étudiants.</p></section>
<?php if ($errors): ?><div class="alert error"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if ($success): ?><div class="alert success"><?= e($success) ?></div><?php endif; ?>
<div class="feed-layout">
 <section class="feed-main" aria-label="Publications">
  <form class="publish-card" method="post" enctype="multipart/form-data">
   <?= csrf_field() ?><input type="hidden" name="action" value="publish">
   <div class="publish-heading"><div class="publish-avatar"><?php $me = $pdo->prepare('SELECT first_name,last_name,avatar_path FROM users WHERE id=?'); $me->execute([$uid]); $me=$me->fetch(); ?><?php if (!empty($me['avatar_path'])): ?><img src="<?= e($me['avatar_path']) ?>" alt=""><?php else: ?><?= e(mb_strtoupper(mb_substr($me['first_name'] ?? 'E',0,1).mb_substr($me['last_name'] ?? '',0,1))) ?><?php endif; ?></div><div><strong>Quoi de neuf ?</strong><small>Une idée, un projet, une découverte…</small></div></div>
   <label class="sr-only" for="post-content">Contenu de la publication</label><textarea id="post-content" name="content" rows="4" maxlength="5000" placeholder="Partage quelque chose avec la communauté…"></textarea>
   <div class="publish-options"><label class="feed-file-label" for="post-image"><span aria-hidden="true">＋</span> Ajouter une photo</label><input class="sr-only" id="post-image" type="file" name="post_image" accept="image/jpeg,image/png,image/webp,image/gif"><span id="post-image-name" class="feed-file-name">JPG, PNG, WEBP ou GIF · 5 Mo max.</span><label class="visibility-label" for="post-visibility">Audience</label><select id="post-visibility" name="visibility"><option value="public">Tous les étudiants</option><option value="friends">Mes amis</option></select></div>
   <div class="publish-bottom"><span>Reste respectueux et protège tes informations personnelles.</span><button class="button primary" type="submit">Publier <span aria-hidden="true">→</span></button></div>
  </form>
  <?php if (!$posts): ?><div class="empty-state feed-empty"><div class="feed-empty-icon">✦</div><h3>Le fil est encore calme</h3><p>Sois parmi les premiers à partager une idée, un projet ou une photo.</p></div><?php endif; ?>
  <?php foreach ($posts as $post): ?><article class="feed-post" id="post-<?= (int)$post['id'] ?>">
   <header class="feed-post-header"><a class="feed-avatar profile-click-avatar" href="student.php?id=<?=(int)$post['user_id']?>"><?php if (!empty($post['avatar_path'])): ?><img src="<?= e($post['avatar_path']) ?>" alt=""><?php else: ?><?= e(mb_strtoupper(mb_substr($post['first_name'],0,1).mb_substr($post['last_name'],0,1))) ?><?php endif; ?></a><div class="feed-author"><strong><a class="student-name-link" href="student.php?id=<?=(int)$post['user_id']?>"><?= e($post['first_name'].' '.$post['last_name']) ?></a></strong><small><?= e($post['filiere'] ?: 'Étudiant UNCHK') ?> · <?= e(date('d/m/Y à H:i', strtotime($post['created_at']))) ?></small></div><span class="feed-audience"><?= $post['visibility']==='friends' ? 'Amis' : 'Public' ?></span><?php if ((int)$post['user_id']===$uid): ?><form method="post" onsubmit="return confirm('Supprimer cette publication ? Cette action est irréversible.');"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="post_id" value="<?= (int)$post['id'] ?>"><button class="feed-delete" type="submit" aria-label="Supprimer la publication">Supprimer</button></form><?php endif; ?></header>
   <?php if (trim($post['content']) !== ''): ?><div class="feed-post-content"><?= nl2br(e($post['content'])) ?></div><?php endif; ?>
   <?php if (!empty($post['image_path'])): ?><img class="feed-post-image" src="<?= e($post['image_path']) ?>" alt="Photo publiée par <?= e($post['first_name']) ?>" loading="lazy"><?php endif; ?>
   <div class="feed-stats"><span><?= (int)$post['like_count'] ?> J’aime</span><span><?= (int)$post['comment_count'] ?> commentaire(s)</span></div><?php if ((int)$post['user_id'] !== $uid): ?><form method="post" class="feed-report-form" data-confirm="Le signalement sera transmis à la modération pour examen." data-confirm-title="Signaler cette publication ?" data-confirm-button="Envoyer le signalement"><?= csrf_field() ?><input type="hidden" name="action" value="report_post"><input type="hidden" name="post_id" value="<?= (int)$post['id'] ?>"><input type="hidden" name="reason" value="Contenu à examiner"><button class="feed-action-button feed-report-button" type="submit"><span aria-hidden="true">⚑</span> Signaler la publication</button></form><?php endif; ?>
   <div class="feed-actions"><form method="post"><?= csrf_field() ?><input type="hidden" name="action" value="like"><input type="hidden" name="post_id" value="<?= (int)$post['id'] ?>"><button class="feed-action-button <?= $post['liked_by_me'] ? 'is-liked' : '' ?>" type="submit"><?= $post['liked_by_me'] ? '♥ Aimé' : '♡ J’aime' ?></button></form><a class="feed-action-button" href="#comment-<?= (int)$post['id'] ?>">▢ Commenter</a></div>
   <div class="feed-comments"><?php foreach (($commentsByPost[(int)$post['id']] ?? []) as $comment): ?><div class="feed-comment"><div class="feed-comment-avatar"><?php if (!empty($comment['avatar_path'])): ?><img src="<?= e($comment['avatar_path']) ?>" alt=""><?php else: ?><?= e(mb_strtoupper(mb_substr($comment['first_name'],0,1).mb_substr($comment['last_name'],0,1))) ?><?php endif; ?></div><div class="feed-comment-bubble"><strong><a class="student-name-link" href="student.php?id=<?=(int)$comment['user_id']?>"><?= e($comment['first_name'].' '.$comment['last_name']) ?></a></strong><p><?= nl2br(e($comment['content'])) ?></p><small><?= e(date('d/m/Y H:i', strtotime($comment['created_at']))) ?></small><?php if ((int)$comment['user_id'] === $uid): ?><form method="post" class="feed-comment-delete-form" data-confirm="Ce commentaire sera supprimé définitivement du fil d’actualité." data-confirm-title="Supprimer ce commentaire ?" data-confirm-button="Oui, supprimer"><?= csrf_field() ?><input type="hidden" name="action" value="delete_comment"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="post_id" value="<?= (int)$post['id'] ?>"><button class="feed-action-button feed-delete-button" type="submit"><span aria-hidden="true">⌫</span> Supprimer</button></form><?php elseif ((int)$comment['user_id'] !== $uid): ?><form method="post" class="feed-comment-delete-form" data-confirm="Le signalement sera transmis à la modération pour examen." data-confirm-title="Signaler ce commentaire ?" data-confirm-button="Envoyer le signalement"><?= csrf_field() ?><input type="hidden" name="action" value="report_comment"><input type="hidden" name="comment_id" value="<?= (int)$comment['id'] ?>"><input type="hidden" name="reason" value="Commentaire à examiner"><button class="feed-action-button feed-report-button feed-comment-report-button" type="submit"><span aria-hidden="true">⚑</span> Signaler</button></form><?php endif; ?></div></div><?php endforeach; ?></div>
   <form class="feed-comment-form" id="comment-<?= (int)$post['id'] ?>" method="post"><?= csrf_field() ?><input type="hidden" name="action" value="comment"><input type="hidden" name="post_id" value="<?= (int)$post['id'] ?>"><label class="sr-only" for="comment-text-<?= (int)$post['id'] ?>">Écrire un commentaire</label><input id="comment-text-<?= (int)$post['id'] ?>" type="text" name="comment" maxlength="1500" placeholder="Écrire un commentaire…" required><button class="button secondary" type="submit">Envoyer</button></form>
  </article><?php endforeach; ?>
 </section>
 <aside class="feed-aside"><div class="feed-side-card"><span class="feed-side-icon">✦</span><h2>Fais vivre la communauté</h2><p>Partage tes apprentissages, demande des conseils et valorise tes projets.</p><a href="projects.php" class="button secondary">Voir les projets</a></div><div class="feed-side-card"><h2>Ton réseau</h2><p>Les publications réservées aux amis sont visibles uniquement par toi et tes amis acceptés.</p><a href="friends.php" class="text-link">Gérer mes amis →</a><a href="directory.php" class="text-link">Découvrir les étudiants →</a></div></aside>
</div>
<script>
(() => { const input = document.getElementById('post-image'); const label = document.getElementById('post-image-name'); if (input && label) input.addEventListener('change', () => { label.textContent = input.files && input.files[0] ? input.files[0].name : 'JPG, PNG, WEBP ou GIF · 5 Mo max.'; }); })();
</script>
<?php page_end(); ?>
