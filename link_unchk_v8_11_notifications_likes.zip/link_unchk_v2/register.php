<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }

$errors = [];
$first = $last = $email = $filiere = $eno = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $first = trim((string)($_POST['first_name'] ?? ''));
    $last = trim((string)($_POST['last_name'] ?? ''));
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $filiere = trim((string)($_POST['filiere'] ?? ''));
    $eno = trim((string)($_POST['eno'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['confirm_password'] ?? '');

    if ($first === '' || mb_strlen($first) > 100) $errors[] = 'Saisis un prénom valide.';
    if ($last === '' || mb_strlen($last) > 100) $errors[] = 'Saisis un nom valide.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) $errors[] = 'Saisis une adresse e-mail valide.';
    if ($filiere === '' || mb_strlen($filiere) > 150) $errors[] = 'Indique ta filière.';
    if ($eno === '' || mb_strlen($eno) > 150) $errors[] = 'Indique ton ENO.';
    if (strlen($password) < 10) $errors[] = 'Le mot de passe doit contenir au moins 10 caractères.';
    if ($password !== $confirm) $errors[] = 'Les mots de passe ne correspondent pas.';

    if (!$errors) {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $check->execute([$email]);
        if ($check->fetch()) {
            $errors[] = 'Cette adresse e-mail possède déjà un compte.';
        } else {
            $stmt = $pdo->prepare('INSERT INTO users (first_name, last_name, email, password_hash, filiere, eno) VALUES (?, ?, ?, ?, ?, ?)');
            try {
                $stmt->execute([$first, $last, $email, password_hash($password, PASSWORD_DEFAULT), $filiere, $eno]);
                session_regenerate_id(true);
                $_SESSION['user_id'] = (int)$pdo->lastInsertId();
                $_SESSION['first_name'] = $first;
                header('Location: dashboard.php?welcome=1');
                exit;
            } catch (PDOException $e) {
                error_log($e->getMessage());
                $errors[] = 'Inscription impossible pour le moment. Vérifie les informations puis réessaie.';
            }
        }
    }
}
page_start('Créer un compte');
?>
<section class="auth-layout">
  <div class="auth-intro"><div class="eyebrow"><span class="dot"></span> Ta communauté commence ici</div><h1>Crée ton<br><span>espace étudiant.</span></h1><p>Un profil pour te faire connaître, partager tes compétences et rejoindre des projets.</p><ul class="check-list"><li>Ton réseau universitaire</li><li>Tes projets et compétences</li><li>Les événements de la communauté</li></ul></div>
  <div class="form-card">
    <div class="form-heading"><h2>Créer un compte</h2><p>Renseigne tes informations pour commencer.</p></div>
    <?php if ($errors): ?><div class="alert error"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <form method="post" action="register.php" autocomplete="on">
      <?= csrf_field() ?>
      <div class="form-row"><label>Prénom<input name="first_name" maxlength="100" value="<?= e($first) ?>" autocomplete="given-name" required></label><label>Nom<input name="last_name" maxlength="100" value="<?= e($last) ?>" autocomplete="family-name" required></label></div>
      <label>E-mail universitaire<input type="email" name="email" maxlength="190" value="<?= e($email) ?>" autocomplete="email" placeholder="nom@exemple.sn" required></label>
      <div class="form-row"><label>Filière<input name="filiere" maxlength="150" value="<?= e($filiere) ?>" placeholder="Ex. Informatique" required></label><label>ENO<input name="eno" maxlength="150" value="<?= e($eno) ?>" placeholder="Ton ENO" required></label></div>
      <label>Mot de passe<input type="password" name="password" minlength="10" autocomplete="new-password" required><small>10 caractères minimum.</small></label>
      <label>Confirmer le mot de passe<input type="password" name="confirm_password" minlength="10" autocomplete="new-password" required></label>
      <button class="button primary full" type="submit">Créer mon compte <span>→</span></button>
    </form>
    <p class="form-bottom">Déjà inscrit ? <a href="login.php">Connecte-toi</a></p>
    <p class="fine-print">Version locale de développement : la confirmation par e-mail universitaire sera ajoutée dans une prochaine étape.</p>
  </div>
</section>
<?php page_end(); ?>
