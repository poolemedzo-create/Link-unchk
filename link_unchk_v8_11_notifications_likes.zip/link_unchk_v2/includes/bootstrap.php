<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    ]);
    session_start();
}

require_once __DIR__ . '/../config/database.php';

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' .
        e($_SESSION['csrf_token'] ?? '') . '">';
}

function check_csrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(419);
        exit('Formulaire expiré. Recharge la page et réessaie.');
    }
}

/** Enregistre une notification sans faire échouer l’action principale si la table manque. */
function create_notification(PDO $pdo, int $userId, string $type, string $message, ?int $relatedId = null): bool {
    if ($userId < 1) return false;
    try {
        $insert = $pdo->prepare('INSERT INTO notifications (user_id,type,message,related_id) VALUES (?,?,?,?)');
        $insert->execute([$userId, $type, mb_substr($message, 0, 500), $relatedId]);
        return true;
    } catch (Throwable $firstError) {
        // Répare automatiquement les installations où la migration communautaire n’a pas créé la table.
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT UNSIGNED NOT NULL,
                type VARCHAR(60) NOT NULL,
                message VARCHAR(500) NOT NULL,
                related_id BIGINT UNSIGNED NULL,
                is_read TINYINT(1) NOT NULL DEFAULT 0,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                INDEX idx_notifications_user (user_id,is_read,created_at),
                CONSTRAINT fk_v7_notifications_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $insert = $pdo->prepare('INSERT INTO notifications (user_id,type,message,related_id) VALUES (?,?,?,?)');
            $insert->execute([$userId, $type, mb_substr($message, 0, 500), $relatedId]);
            return true;
        } catch (Throwable $retryError) {
            error_log('Link UNCHK notification: '.$retryError->getMessage());
            return false;
        }
    }
}

function require_login(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

function page_start(string $title): void {
    $unreadMessages = 0;
    $unreadNotifications = 0;
    $totalStudents = 0;
    try { global $pdo; $totalStudents = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(); } catch (Throwable $ignored) { $totalStudents = 0; }
    if (!empty($_SESSION['user_id'])) {
        global $pdo;
        try { $unreadQuery = $pdo->prepare('SELECT COUNT(*) FROM private_messages WHERE receiver_id=? AND read_at IS NULL'); $unreadQuery->execute([(int)$_SESSION['user_id']]); $unreadMessages = (int)$unreadQuery->fetchColumn(); } catch (Throwable $ignored) { $unreadMessages = 0; }
        try { $notificationQuery = $pdo->prepare('SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0'); $notificationQuery->execute([(int)$_SESSION['user_id']]); $unreadNotifications = (int)$notificationQuery->fetchColumn(); } catch (Throwable $ignored) { $unreadNotifications = 0; }
    }
    ?><!doctype html>
    <html lang="fr">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title><?= e($title) ?> · Link UNCHK</title>
      <link rel="stylesheet" href="assets/css/style.css">
      <script>try{if(localStorage.getItem('link-unchk-theme')==='dark')document.documentElement.classList.add('dark-mode')}catch(e){}</script>
    </head>
    <body>
    <header class="topbar">
      <a class="brand" href="index.php"><span class="brand-mark">L</span><span>Link <b>UNCHK</b></span></a>
      <button class="nav-toggle" type="button" aria-label="Ouvrir le menu" aria-expanded="false" aria-controls="main-navigation"><span></span><span></span><span></span></button>
      <nav id="main-navigation">
        <?php if (!empty($_SESSION['user_id'])): ?>
          <a class="nav-main-link" href="dashboard.php">Mon espace</a>
          <details class="nav-menu"><summary>Communauté</summary><div class="nav-dropdown">
            <a href="feed.php">Fil d’actualité</a><a href="directory.php">Annuaire étudiant <span class="nav-count"><?= number_format($totalStudents, 0, ',', ' ') ?></span></a><a href="friends.php">Mes amis</a>
          </div></details>
          <details class="nav-menu"><summary>Messages<?php if ($unreadMessages > 0): ?> <span class="nav-unread"><?= $unreadMessages > 99 ? '99+' : $unreadMessages ?></span><?php endif; ?></summary><div class="nav-dropdown">
            <a href="messages.php">Messagerie privée<?php if ($unreadMessages > 0): ?> <span class="nav-unread"><?= $unreadMessages > 99 ? '99+' : $unreadMessages ?></span><?php endif; ?></a><a href="groups.php">Groupes étudiants</a><a href="notifications.php">Notifications<?php if ($unreadNotifications > 0): ?> <span class="nav-unread"><?= $unreadNotifications > 99 ? '99+' : $unreadNotifications ?></span><?php endif; ?></a>
          </div></details>
          <details class="nav-menu"><summary>Études</summary><div class="nav-dropdown"><a href="academic.php">Espace académique</a><a href="projects.php">Projets étudiants</a></div></details>
          <details class="nav-menu"><summary>Compte</summary><div class="nav-dropdown"><a href="student.php?id=<?= (int)$_SESSION['user_id'] ?>">Mon profil</a><a class="nav-logout" href="logout.php">Déconnexion</a></div></details>
          <button class="theme-toggle" type="button" aria-label="Activer le mode sombre" title="Changer de thème"><span class="theme-icon">☾</span><span class="theme-label">Mode sombre</span></button>
        <?php else: ?>
          <a href="login.php">Connexion</a>
          <a class="nav-cta" href="register.php">Créer un compte</a>
        <?php endif; ?>
      </nav>
    </header>
    <div class="confirm-overlay" id="logoutConfirm" hidden role="dialog" aria-modal="true" aria-labelledby="logoutConfirmTitle" aria-describedby="logoutConfirmText">
      <div class="confirm-dialog">
        <div class="confirm-dialog-icon" aria-hidden="true">↗</div>
        <h2 id="logoutConfirmTitle">Se déconnecter ?</h2>
        <p id="logoutConfirmText">Tu vas quitter ta session Link UNCHK. Es-tu sûr de vouloir te déconnecter ?</p>
        <div class="confirm-dialog-actions"><button type="button" class="button secondary" id="cancelLogout">Annuler</button><a class="button danger" id="confirmLogoutLink" href="logout.php">Oui, me déconnecter</a></div>
      </div>
    </div>
    <div class="confirm-overlay" id="actionConfirm" hidden role="dialog" aria-modal="true" aria-labelledby="actionConfirmTitle" aria-describedby="actionConfirmText">
      <div class="confirm-dialog">
        <div class="confirm-dialog-icon" id="actionConfirmIcon" aria-hidden="true">!</div>
        <h2 id="actionConfirmTitle">Confirmer cette action ?</h2>
        <p id="actionConfirmText">Veux-tu vraiment continuer ?</p>
        <div class="confirm-dialog-actions"><button type="button" class="button secondary" id="cancelActionConfirm">Annuler</button><button type="button" class="button danger" id="acceptActionConfirm">Confirmer</button></div>
      </div>
    </div>
    <script>
    (() => {
      const themeButton = document.querySelector('.theme-toggle');
      const logoutModal = document.getElementById('logoutConfirm');
      const cancelLogout = document.getElementById('cancelLogout');
      const confirmLogoutLink = document.getElementById('confirmLogoutLink');
      document.querySelectorAll('a.nav-logout, a[href$="logout.php"]').forEach(link => {
        link.addEventListener('click', event => {
          if (!logoutModal) return;
          event.preventDefault();
          confirmLogoutLink.href = link.href;
          logoutModal.hidden = false;
          document.body.classList.add('modal-open');
          cancelLogout.focus();
        });
      });
      const closeLogoutModal = () => { if(logoutModal){logoutModal.hidden=true;document.body.classList.remove('modal-open');} };
      if(cancelLogout) cancelLogout.addEventListener('click', closeLogoutModal);
      if(logoutModal) logoutModal.addEventListener('click', event => { if(event.target===logoutModal) closeLogoutModal(); });
      const actionModal=document.getElementById('actionConfirm');
      const actionTitle=document.getElementById('actionConfirmTitle');
      const actionText=document.getElementById('actionConfirmText');
      const actionAccept=document.getElementById('acceptActionConfirm');
      const actionCancel=document.getElementById('cancelActionConfirm');
      let pendingConfirmForm=null;
      const closeActionModal=()=>{if(actionModal){actionModal.hidden=true;document.body.classList.remove('modal-open');}pendingConfirmForm=null;};
      document.querySelectorAll('form[data-confirm]').forEach(form=>form.addEventListener('submit',event=>{
        if(form.dataset.confirmed==='1'){delete form.dataset.confirmed;return;}
        event.preventDefault(); pendingConfirmForm=form;
        actionTitle.textContent=form.dataset.confirmTitle||'Confirmer cette action ?';
        actionText.textContent=form.dataset.confirm||'Veux-tu vraiment continuer ?';
        actionAccept.textContent=form.dataset.confirmButton||'Confirmer';
        actionModal.hidden=false;document.body.classList.add('modal-open');actionCancel.focus();
      }));
      actionAccept.addEventListener('click',()=>{if(!pendingConfirmForm)return;const form=pendingConfirmForm;form.dataset.confirmed='1';closeActionModal();if(form.requestSubmit)form.requestSubmit();else form.submit();});
      actionCancel.addEventListener('click',closeActionModal);
      actionModal.addEventListener('click',event=>{if(event.target===actionModal)closeActionModal();});
      document.addEventListener('keydown', event => { if(event.key==='Escape'){if(logoutModal&&!logoutModal.hidden)closeLogoutModal();if(actionModal&&!actionModal.hidden)closeActionModal();} });
      const updateThemeButton = () => { if(!themeButton)return; const dark=document.documentElement.classList.contains('dark-mode'); themeButton.querySelector('.theme-icon').textContent=dark?'☀':'☾'; themeButton.querySelector('.theme-label').textContent=dark?'Mode clair':'Mode sombre'; themeButton.setAttribute('aria-label',dark?'Activer le mode clair':'Activer le mode sombre'); };
      updateThemeButton();
      if(themeButton)themeButton.addEventListener('click',()=>{const dark=document.documentElement.classList.toggle('dark-mode');try{localStorage.setItem('link-unchk-theme',dark?'dark':'light')}catch(e){}updateThemeButton();});
      const toggle = document.querySelector('.nav-toggle');
      const nav = document.getElementById('main-navigation');
      if (!toggle || !nav) return;
      toggle.addEventListener('click', () => {
        const opened = nav.classList.toggle('is-open');
        toggle.classList.toggle('is-active', opened);
        toggle.setAttribute('aria-expanded', String(opened));
        toggle.setAttribute('aria-label', opened ? 'Fermer le menu' : 'Ouvrir le menu');
      });
      nav.querySelectorAll('.nav-menu > summary').forEach(summary => {
        summary.addEventListener('click', () => {
          const parent = summary.parentElement;
          nav.querySelectorAll('.nav-menu[open]').forEach(menu => {
            if (menu !== parent) menu.removeAttribute('open');
          });
        });
      });
      document.addEventListener('click', event => {
        if (window.matchMedia('(max-width: 900px)').matches && !nav.contains(event.target) && !toggle.contains(event.target)) {
          nav.classList.remove('is-open');
          toggle.classList.remove('is-active');
          toggle.setAttribute('aria-expanded', 'false');
          toggle.setAttribute('aria-label', 'Ouvrir le menu');
        }
      });
    })();
    </script>
    <main class="page">
    <?php
}

function page_end(): void {
    ?></main><footer class="footer">Link UNCHK · Le réseau des étudiants, par les étudiants.</footer></body></html><?php
}
