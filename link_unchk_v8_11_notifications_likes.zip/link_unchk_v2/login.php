<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (!empty($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }
$error = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $password = (string)($_POST['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $password === '') {
        $error = 'Saisis ton e-mail et ton mot de passe.';
    } else {
        $stmt = $pdo->prepare('SELECT id, first_name, password_hash FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password_hash'])) {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['first_name'] = $user['first_name'];
            header('Location: dashboard.php');
            exit;
        }
        $error = 'E-mail ou mot de passe incorrect.';
    }
}
page_start('Connexion');
?>
<section class="login-wrap">
  <div class="form-card login-card">
    <div class="form-heading centered"><div class="brand-mark large">L</div><h2>Content de te revoir.</h2><p>Connecte-toi pour retrouver ta communauté.</p></div>
    <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" action="login.php">
      <?= csrf_field() ?>
      <label>E-mail universitaire<input type="email" name="email" maxlength="190" value="<?= e($email) ?>" autocomplete="email" required></label>
      <label>Mot de passe<input type="password" name="password" autocomplete="current-password" required></label>
      <button class="button primary full" type="submit">Se connecter <span>→</span></button>
    </form>
    <p class="form-bottom">Nouveau sur Link UNCHK ? <a href="register.php">Créer un compte</a></p>
  </div>
</section>
<?php page_end(); ?>
