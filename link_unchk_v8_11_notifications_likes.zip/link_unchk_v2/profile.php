<?php
require_once __DIR__ . '/includes/bootstrap.php'; require_login();
$userId=(int)$_SESSION['user_id'];
$st=$pdo->prepare('SELECT first_name,last_name,email,filiere,eno,bio,avatar_path FROM users WHERE id=?'); $st->execute([$userId]); $user=$st->fetch();
if(!$user){header('Location: logout.php');exit;}
$skills=[]; $migrationMissing=false;
try{$q=$pdo->prepare('SELECT skill_name FROM user_skills WHERE user_id=? ORDER BY skill_name');$q->execute([$userId]);$skills=$q->fetchAll(PDO::FETCH_COLUMN);}catch(PDOException $e){$migrationMissing=true;}
$errors=[]; $success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 check_csrf(); $first=trim((string)($_POST['first_name']??''));$last=trim((string)($_POST['last_name']??''));$filiere=trim((string)($_POST['filiere']??''));$eno=trim((string)($_POST['eno']??''));$bio=trim((string)($_POST['bio']??''));$skillsRaw=trim((string)($_POST['skills']??''));
 if($first===''||mb_strlen($first)>100)$errors[]='Prénom invalide.';if($last===''||mb_strlen($last)>100)$errors[]='Nom invalide.';if($filiere===''||mb_strlen($filiere)>150)$errors[]='Indique ta filière.';if($eno===''||mb_strlen($eno)>150)$errors[]='Indique ton ENO.';if(mb_strlen($bio)>1500)$errors[]='La biographie doit faire au maximum 1 500 caractères.';
 $newAvatar=null;
 if(isset($_FILES['avatar'])&&$_FILES['avatar']['error']!==UPLOAD_ERR_NO_FILE){$f=$_FILES['avatar'];if($f['error']!==UPLOAD_ERR_OK)$errors[]='Le téléversement de la photo a échoué.';elseif($f['size']>2*1024*1024)$errors[]='La photo doit peser 2 Mo maximum.';else{$info=@getimagesize($f['tmp_name']);$mime=$info['mime']??'';$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;if(!$ext)$errors[]='Utilise une image JPG, PNG ou WEBP.';else{$dir=__DIR__.'/uploads/avatars';if(!is_dir($dir))mkdir($dir,0755,true);$name='avatar_'.$userId.'_'.bin2hex(random_bytes(8)).'.'.$ext;$dest=$dir.'/'.$name;if(move_uploaded_file($f['tmp_name'],$dest))$newAvatar='uploads/avatars/'.$name;else$errors[]='Impossible d’enregistrer la photo.';}}}
 if(!$errors){try{$pdo->beginTransaction();if($newAvatar){$up=$pdo->prepare('UPDATE users SET first_name=?,last_name=?,filiere=?,eno=?,bio=?,avatar_path=? WHERE id=?');$up->execute([$first,$last,$filiere,$eno,$bio?:null,$newAvatar,$userId]);}else{$up=$pdo->prepare('UPDATE users SET first_name=?,last_name=?,filiere=?,eno=?,bio=? WHERE id=?');$up->execute([$first,$last,$filiere,$eno,$bio?:null,$userId]);}
 if(!$migrationMissing){$pdo->prepare('DELETE FROM user_skills WHERE user_id=?')->execute([$userId]);$unique=[];foreach(explode(',',$skillsRaw) as $sk){$sk=trim($sk);if($sk!==''&&mb_strlen($sk)<=80)$unique[mb_strtolower($sk)]=$sk;}foreach(array_slice(array_values($unique),0,20) as $sk){$ins=$pdo->prepare('INSERT INTO user_skills(user_id,skill_name) VALUES(?,?)');$ins->execute([$userId,$sk]);}}
 $pdo->commit();$_SESSION['first_name']=$first;$success='Ton profil a été mis à jour.';$st->execute([$userId]);$user=$st->fetch();$skills=[];if(!$migrationMissing){$q=$pdo->prepare('SELECT skill_name FROM user_skills WHERE user_id=? ORDER BY skill_name');$q->execute([$userId]);$skills=$q->fetchAll(PDO::FETCH_COLUMN);}
 }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log($e->getMessage());$errors[]='Enregistrement impossible. Vérifie que la migration v2 a bien été importée.';}}
}
page_start('Modifier mon profil');
?>
<section class="content-narrow"><div class="eyebrow"><span class="dot"></span> Profil étudiant</div><h1 class="page-title">Fais connaissance avec la communauté.</h1><p class="muted">Mets à jour tes informations et montre ce que tu sais faire.</p>
<?php if($migrationMissing): ?><div class="alert error">Pour activer les compétences, importe le fichier <code>migrations/upgrade_profils_projets.sql</code> dans phpMyAdmin, dans la base <strong>link_unchk</strong>.</div><?php endif; ?>
<?php if($errors): ?><div class="alert error"><ul><?php foreach($errors as $er):?><li><?=e($er)?></li><?php endforeach;?></ul></div><?php endif;?><?php if($success):?><div class="alert success"><?=e($success)?></div><?php endif;?>
<div class="form-card"><form method="post" enctype="multipart/form-data"><?=csrf_field()?>
<div class="avatar-preview-row">
<?php if($user['avatar_path']):?><img class="profile-avatar" id="avatarPreview" src="<?=e($user['avatar_path'])?>" alt="Photo actuelle"><?php else:?><div class="profile-initials small-initials" id="avatarInitials"><?=e(mb_strtoupper(mb_substr($user['first_name'],0,1).mb_substr($user['last_name'],0,1)))?></div><?php endif;?>
<div class="avatar-upload-block"><span class="upload-label">Photo de profil</span><label class="file-picker" for="avatarFile"><span class="file-picker-icon" aria-hidden="true">↑</span><span class="file-picker-copy"><strong>Choisir une photo</strong><small id="avatarFileName">Aucun fichier sélectionné</small></span><input id="avatarFile" type="file" name="avatar" accept="image/jpeg,image/png,image/webp"></label><small class="upload-hint">JPG, PNG ou WEBP · 2 Mo maximum.</small></div></div>
<script>
(()=>{const input=document.getElementById('avatarFile');const name=document.getElementById('avatarFileName');const preview=document.getElementById('avatarPreview');const initials=document.getElementById('avatarInitials');if(!input)return;input.addEventListener('change',()=>{const file=input.files&&input.files[0];name.textContent=file?file.name:'Aucun fichier sélectionné';if(file&&file.type.startsWith('image/')){const reader=new FileReader();reader.onload=event=>{if(preview){preview.src=event.target.result;}else if(initials){const img=document.createElement('img');img.className='profile-avatar';img.id='avatarPreview';img.alt='Aperçu de la nouvelle photo';img.src=event.target.result;initials.replaceWith(img);}};reader.readAsDataURL(file);}});})();
</script>
<div class="form-row"><label>Prénom<input name="first_name" maxlength="100" required value="<?=e($user['first_name'])?>"></label><label>Nom<input name="last_name" maxlength="100" required value="<?=e($user['last_name'])?>"></label></div>
<label>E-mail (non modifiable)<input value="<?=e($user['email'])?>" disabled></label><div class="form-row"><label>Filière<input name="filiere" maxlength="150" required value="<?=e($user['filiere'])?>"></label><label>ENO<input name="eno" maxlength="150" required value="<?=e($user['eno'])?>"></label></div>
<label>Biographie<textarea name="bio" rows="5" maxlength="1500" placeholder="Présente-toi, parle de tes centres d’intérêt…"><?=e($user['bio']??'')?></textarea><small>1 500 caractères maximum.</small></label>
<label>Compétences<input name="skills" maxlength="1600" value="<?=e(implode(', ',$skills))?>" placeholder="PHP, Python, Réseaux, Design"><small>Sépare les compétences par des virgules (20 maximum).</small></label>
<button class="button primary full" type="submit">Enregistrer les modifications <span>→</span></button></form></div><p class="form-bottom"><a href="dashboard.php">← Retour à mon espace</a></p></section>
<?php page_end(); ?>
