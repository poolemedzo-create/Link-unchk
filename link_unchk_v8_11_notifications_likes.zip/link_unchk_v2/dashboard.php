<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
$stmt = $pdo->prepare('SELECT id, first_name, last_name, email, filiere, eno, bio, avatar_path, created_at FROM users WHERE id = ? LIMIT 1');
$stmt->execute([(int)$_SESSION['user_id']]);
$user = $stmt->fetch();
if (!$user) { $_SESSION = []; session_destroy(); header('Location: login.php'); exit; }
$skills = [];
try { $st = $pdo->prepare('SELECT skill_name FROM user_skills WHERE user_id = ? ORDER BY skill_name'); $st->execute([$user['id']]); $skills = $st->fetchAll(PDO::FETCH_COLUMN); } catch (PDOException $e) { /* Importer la migration v2 pour activer les compétences. */ }
$projectsStmt = $pdo->prepare('SELECT id,title,description,status,technologies FROM projects WHERE user_id=? ORDER BY created_at DESC LIMIT 3');
$projectsStmt->execute([$user['id']]); $projects = $projectsStmt->fetchAll();
try { $totalStudents = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(); } catch (PDOException $e) { $totalStudents = 0; }
try { $totalResources = (int)$pdo->query('SELECT COUNT(*) FROM academic_resources')->fetchColumn(); } catch (PDOException $e) { $totalResources = 0; }
try { $totalProjects = (int)$pdo->query('SELECT COUNT(*) FROM projects')->fetchColumn(); } catch (PDOException $e) { $totalProjects = 0; }
page_start('Mon espace');
?>
<section class="dashboard-head">
 <div><div class="eyebrow"><span class="dot"></span> Ton espace personnel</div><h1>Bienvenue, <span><?= e($user['first_name']) ?>.</span></h1><p>Présente tes compétences, découvre les étudiants de l’UNCHK et partage tes projets.</p><div class="actions"><a class="button secondary" href="directory.php">Découvrir les étudiants</a><a class="button secondary" href="feed.php">Ouvrir le fil d’actualité</a></div></div>
 <?php if (!empty($user['avatar_path'])): ?><img class="profile-avatar" src="<?= e($user['avatar_path']) ?>" alt="Photo de profil"><?php else: ?><div class="profile-initials"><?= e(mb_strtoupper(mb_substr($user['first_name'],0,1).mb_substr($user['last_name'],0,1))) ?></div><?php endif; ?>
</section>
<section class="community-stats" aria-label="Statistiques de la communauté">
 <a class="community-stat" href="directory.php"><span class="community-stat-icon">♙</span><span><small>Étudiants inscrits</small><strong><?= number_format($totalStudents, 0, ',', ' ') ?></strong><em>Voir l’annuaire →</em></span></a>
 <a class="community-stat" href="academic.php"><span class="community-stat-icon">▤</span><span><small>Ressources académiques</small><strong><?= number_format($totalResources, 0, ',', ' ') ?></strong><em>Consulter les ressources →</em></span></a>
 <a class="community-stat" href="projects.php"><span class="community-stat-icon">⌘</span><span><small>Projets étudiants</small><strong><?= number_format($totalProjects, 0, ',', ' ') ?></strong><em>Découvrir les projets →</em></span></a>
</section>

<section class="section-head"><div><h2>Mes projets</h2><p>Présente ce que tu construis et les technologies utilisées.</p></div><a class="button primary" href="projects.php">Gérer mes projets</a></section>
<?php if ($projects): ?><section class="project-grid"><?php foreach($projects as $project): ?><article class="project-card"><span class="status-pill"><?= e(['in_progress'=>'En cours','completed'=>'Terminé','looking_for_team'=>'Recherche d’équipe'][$project['status']] ?? $project['status']) ?></span><h3><?= e($project['title']) ?></h3><p><?= e(mb_strimwidth($project['description'],0,180,'…')) ?></p><?php if ($project['technologies']): ?><small><?= e($project['technologies']) ?></small><?php endif; ?></article><?php endforeach; ?></section><?php else: ?><div class="empty-state"><h3>Ton portfolio commence ici</h3><p>Ajoute ton premier projet et partage-le avec la communauté.</p><a href="projects.php" class="button primary">Ajouter un projet</a></div><?php endif; ?>
<?php page_end(); ?>
